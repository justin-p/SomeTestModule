UnRegister-NLog
Remove-Module NlogModule
