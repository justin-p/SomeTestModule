﻿---
Module Name: SomeTestModule
Module Guid: 2d7635eb-a838-416b-9b9f-a729bc8e04d8
Download Help Link: https://github.com/justin-p/SomeTestModule/release/SomeTestModule/docs/SomeTestModule.md
Help Version: 0.0.1
Locale: en-US
---

# SomeTestModule Module
## Description
SomeTestModule

## SomeTestModule Cmdlets
### [Write-SomeTestModule](Write-SomeTestModule.md)
A dummy test function


