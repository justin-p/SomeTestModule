﻿---
Module Name: SomeTestModule
Module Guid: ce8e0547-fbaa-42fa-b3c3-39dae45f1727
Download Help Link: https://github.com/justin-p/SomeTestModule/release/SomeTestModule/docs/SomeTestModule.md
Help Version: 0.0.1
Locale: en-US
---

# SomeTestModule Module
## Description
SomeTestModule

## SomeTestModule Cmdlets
### [Get-CallerPreference](Get-CallerPreference.md)
Fetches "Preference" variable values from the caller's scope.


