﻿---
Module Name: SomeTestModule
Module Guid: f414e154-1dec-4782-a47b-6a362e3efc59
Download Help Link: https://github.com/justin-p/SomeTestModule/release/SomeTestModule/docs/SomeTestModule.md
Help Version: 0.0.1
Locale: en-US
---

# SomeTestModule Module
## Description
SomeTestModule

## SomeTestModule Cmdlets
### [Write-SomeTestModule](Write-SomeTestModule.md)
A dummy test function


