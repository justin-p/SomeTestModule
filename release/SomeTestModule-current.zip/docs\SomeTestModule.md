﻿---
Module Name: SomeTestModule
Module Guid: 1294c788-ec43-41eb-bb35-2ae4a9f42992
Download Help Link: https://github.com/justin-p/SomeTestModule/release/SomeTestModule/docs/SomeTestModule.md
Help Version: 0.0.1
Locale: en-US
---

# SomeTestModule Module
## Description
SomeTestModule

## SomeTestModule Cmdlets
### [Write-SomeTestModule](Write-SomeTestModule.md)
A dummy test function


