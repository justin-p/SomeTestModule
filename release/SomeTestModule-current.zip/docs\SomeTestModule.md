﻿---
Module Name: SomeTestModule
Module Guid: 6d765176-59d3-4c1a-9ce9-be043c59ea3f
Download Help Link: https://github.com/justin-p/SomeTestModule/release/SomeTestModule/docs/SomeTestModule.md
Help Version: 0.0.1
Locale: en-US
---

# SomeTestModule Module
## Description
SomeTestModule

## SomeTestModule Cmdlets
### [Get-CallerPreference](Get-CallerPreference.md)
Fetches "Preference" variable values from the caller's scope.


