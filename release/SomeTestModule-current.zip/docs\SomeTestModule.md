﻿---
Module Name: SomeTestModule
Module Guid: 9f89b03c-a465-4d11-bfd7-f2b4890e575f
Download Help Link: https://github.com/justin-p/ModuleBuild/release/SomeTestModule/docs/SomeTestModule.md
Help Version: 0.0.1
Locale: en-US
---

# SomeTestModule Module
## Description
SomeTestModule

## SomeTestModule Cmdlets
### [Get-CallerPreference](Get-CallerPreference.md)
Fetches "Preference" variable values from the caller's scope.


