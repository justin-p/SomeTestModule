﻿---
Module Name: SomeTestModule
Module Guid: 0a9e49ec-e940-4710-88cd-6f1afe028396
Download Help Link: https://github.com/justin-p/SomeTestModule/release/SomeTestModule/docs/SomeTestModule.md
Help Version: 0.0.1
Locale: en-US
---

# SomeTestModule Module
## Description
SomeTestModule

## SomeTestModule Cmdlets
### [Write-SomeTestModule](Write-SomeTestModule.md)
A dummy test function


