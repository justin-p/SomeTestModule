﻿---
external help file: SomeTestModule-help.xml
Module Name: SomeTestModule
online version: https://github.com/justin-p/SomeTestModule
schema: 2.0.0
---

# Write-SomeTestModule

## SYNOPSIS
Simple sample function.

## SYNTAX

```
Write-SomeTestModule [<CommonParameters>]
```

## DESCRIPTION
Simple sample function.
Only Reason this is a thing is to test builds.

## EXAMPLES

### EXAMPLE 1
```
Write-SomeTestModule
```

## PARAMETERS

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable.
For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Author: Justin Perdok

## RELATED LINKS

[https://github.com/justin-p/SomeTestModule](https://github.com/justin-p/SomeTestModule)

